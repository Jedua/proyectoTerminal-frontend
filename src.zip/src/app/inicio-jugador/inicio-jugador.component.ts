import { Component } from '@angular/core';

@Component({
  selector: 'app-inicio-jugador',
  standalone: true,
  imports: [],
  templateUrl: './inicio-jugador.component.html',
  styleUrl: './inicio-jugador.component.css'
})
export class InicioJugadorComponent {

}
