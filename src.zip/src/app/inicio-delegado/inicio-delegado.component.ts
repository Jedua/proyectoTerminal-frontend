import { Component } from '@angular/core';

@Component({
  selector: 'app-inicio-delegado',
  standalone: true,
  imports: [],
  templateUrl: './inicio-delegado.component.html',
  styleUrl: './inicio-delegado.component.css'
})
export class InicioDelegadoComponent {

}
