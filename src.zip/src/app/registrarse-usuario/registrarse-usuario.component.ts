import { Component } from '@angular/core';

@Component({
  selector: 'app-registrarse-usuario',
  standalone: true,
  imports: [],
  templateUrl: './registrarse-usuario.component.html',
  styleUrl: './registrarse-usuario.component.css'
})
export class RegistrarseUsuarioComponent {

}
