import { Component } from '@angular/core';

@Component({
  selector: 'app-inicio-equipo',
  standalone: true,
  imports: [],
  templateUrl: './inicio-equipo.component.html',
  styleUrl: './inicio-equipo.component.css'
})
export class InicioEquipoComponent {

}
